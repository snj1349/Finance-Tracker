using FinanceTrackerDAL.Models;
using Microsoft.EntityFrameworkCore;

namespace FinanceTrackerDAL.Repositories
{
    public class BudgetRepository
    {
        private readonly FinanceTrackerDbContext _context;

        public BudgetRepository()
        {
            _context = new FinanceTrackerDbContext();
        }

        public BudgetRepository(FinanceTrackerDbContext context)
        {
            _context = context;
        }

        // 1. Get all budgets for a specific user
        public List<Budget> GetBudgetsByUser(int userId)
        {
            List<Budget> budgets = new List<Budget>();
            try
            {
                budgets = (from b in _context.Budgets
                           .Include(b => b.Category)
                           where b.UserId == userId
                           orderby b.Year, b.Month, b.Category.Name
                           select b).ToList();
            }
            catch (Exception ex)
            {
                budgets = null;
            }
            return budgets;
        }

        // 2. Get budget by ID
        public Budget? GetBudgetById(int id)
        {
            Budget? budget = null;
            try
            {
                budget = _context.Budgets
                    .Include(b => b.Category)
                    .FirstOrDefault(b => b.BudgetId == id);
            }
            catch (Exception ex)
            {
                budget = null;
            }
            return budget;
        }

        // 3. Add new budget
        public bool AddBudget(Budget budget)
        {
            bool result = false;
            try
            {
                budget.CreatedAt = DateTime.Now;
                _context.Budgets.Add(budget);
                _context.SaveChanges();
                result = true;
            }
            catch (Exception ex)
            {
                result = false;
            }
            return result;
        }

        // 4. Update budget
        public int UpdateBudget(Budget budget)
        {
            int result = 0;
            try
            {
                var existingBudget = _context.Budgets.Find(budget.BudgetId);
                if (existingBudget != null)
                {
                    existingBudget.Amount = budget.Amount;
                    existingBudget.Month = budget.Month;
                    existingBudget.Year = budget.Year;
                    
                    _context.SaveChanges();
                    result = 1;
                }
                else
                {
                    result = -1;
                }
            }
            catch (Exception ex)
            {
                result = -99;
            }
            return result;
        }

        // 5. Delete budget
        public bool DeleteBudget(int id)
        {
            bool result = false;
            try
            {
                var budget = _context.Budgets.Find(id);
                if (budget != null)
                {
                    _context.Budgets.Remove(budget);
                    _context.SaveChanges();
                    result = true;
                }
                else
                {
                    result = false;
                }
            }
            catch (Exception ex)
            {
                result = false;
            }
            return result;
        }

        // 6. Get budget for a specific category, month, and year
        public decimal GetBudgetForCategory(int userId, int categoryId, int month, int year)
        {
            decimal budgetAmount = 0;
            try
            {
                var budget = (from b in _context.Budgets
                              where b.UserId == userId && 
                                    b.CategoryId == categoryId && 
                                    b.Month == month && 
                                    b.Year == year
                              select b).FirstOrDefault();

                budgetAmount = budget?.Amount ?? 0;
            }
            catch (Exception ex)
            {
                budgetAmount = 0;
            }
            return budgetAmount;
        }

        // 7. Check if budget is exceeded for a specific category, month, and year
        public bool IsBudgetExceeded(int userId, int categoryId, int month, int year)
        {
            bool isExceeded = false;
            try
            {
                // Get the budget amount
                var budgetAmount = GetBudgetForCategory(userId, categoryId, month, year);
                
                if (budgetAmount == 0)
                {
                    // No budget set, so it's not exceeded
                    return false;
                }

                // Get total expenses for the category in the specified month and year
                var totalExpenses = (from e in _context.Expenses
                                     where e.UserId == userId && 
                                           e.CategoryId == categoryId && 
                                           e.ExpenseDate.Month == month && 
                                           e.ExpenseDate.Year == year
                                     select e.Amount).Sum();

                isExceeded = totalExpenses > budgetAmount;
            }
            catch (Exception ex)
            {
                isExceeded = false;
            }
            return isExceeded;
        }

        // 8. Get budget vs actual spending for a specific month and year
        public Dictionary<string, (decimal Budget, decimal Actual, decimal Remaining)> GetBudgetVsActual(int userId, int month, int year)
        {
            Dictionary<string, (decimal Budget, decimal Actual, decimal Remaining)> result = new Dictionary<string, (decimal Budget, decimal Actual, decimal Remaining)>();
            try
            {
                // Get all budgets for the user in the specified month and year
                var budgets = (from b in _context.Budgets
                               .Include(b => b.Category)
                               where b.UserId == userId && b.Month == month && b.Year == year
                               select b).ToList();

                foreach (var budget in budgets)
                {
                    // Get actual expenses for this category in the specified month and year
                    var actualExpenses = (from e in _context.Expenses
                                          where e.UserId == userId && 
                                                e.CategoryId == budget.CategoryId && 
                                                e.ExpenseDate.Month == month && 
                                                e.ExpenseDate.Year == year
                                          select e.Amount).Sum();

                    var remaining = budget.Amount - actualExpenses;
                    result[budget.Category.Name] = (budget.Amount, actualExpenses, remaining);
                }
            }
            catch (Exception ex)
            {
                result = new Dictionary<string, (decimal Budget, decimal Actual, decimal Remaining)>();
            }
            return result;
        }
    }
}
