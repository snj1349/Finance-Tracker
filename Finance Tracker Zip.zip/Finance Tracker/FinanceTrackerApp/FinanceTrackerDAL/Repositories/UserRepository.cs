using FinanceTrackerDAL.Models;
using Microsoft.EntityFrameworkCore;

namespace FinanceTrackerDAL.Repositories
{
    public class UserRepository
    {
        private readonly FinanceTrackerDbContext _context;

        public UserRepository()
        {
            _context = new FinanceTrackerDbContext();
        }

        public UserRepository(FinanceTrackerDbContext context)
        {
            _context = context;
        }

        // 1. Get all users
        public List<User> GetAllUsers()
        {
            List<User> users = new List<User>();
            try
            {
                users = _context.Users.ToList();
            }
            catch (Exception ex)
            {
                users = null;
            }
            return users;
        }

        // 2. Get user by ID
        public User? GetUserById(int id)
        {
            User? user = null;
            try
            {
                user = _context.Users.Find(id);
            }
            catch (Exception ex)
            {
                user = null;
            }
            return user;
        }

        // 3. Get user by email (for login)
        public User? GetUserByEmail(string email)
        {
            User? user = null;
            try
            {
                user = _context.Users.FirstOrDefault(u => u.Email == email);
            }
            catch (Exception ex)
            {
                user = null;
            }
            return user;
        }

        // 4. Add new user (register)
        public bool AddUser(User user)
        {
            bool result = false;
            try
            {
                user.CreatedAt = DateTime.Now;
                _context.Users.Add(user);
                _context.SaveChanges();
                result = true;
            }
            catch (Exception ex)
            {
                result = false;
            }
            return result;
        }

        // 5. Update user profile
        public int UpdateUser(User user)
        {
            int result = 0;
            try
            {
                var existingUser = _context.Users.Find(user.UserId);
                if (existingUser != null)
                {
                    existingUser.Name = user.Name;
                    existingUser.Email = user.Email;
                    existingUser.PasswordHash = user.PasswordHash;
                    existingUser.Role = user.Role;
                    
                    _context.SaveChanges();
                    result = 1;
                }
                else
                {
                    result = -1;
                }
            }
            catch (Exception ex)
            {
                result = -99;
            }
            return result;
        }

        // 6. Delete user
        public bool DeleteUser(int id)
        {
            bool result = false;
            try
            {
                var user = _context.Users.Find(id);
                if (user != null)
                {
                    // Check if user has any expenses or budgets
                    bool hasExpenses = _context.Expenses.Any(e => e.UserId == id);
                    bool hasBudgets = _context.Budgets.Any(b => b.UserId == id);
                    
                    if (!hasExpenses && !hasBudgets)
                    {
                        // User has no related data, safe to delete
                        _context.Users.Remove(user);
                        _context.SaveChanges();
                        result = true;
                    }
                    else
                    {
                        // User has related data, cannot delete
                        result = false;
                    }
                }
                else
                {
                    result = false;
                }
            }
            catch (Exception ex)
            {
                result = false;
            }
            return result;
        }
    }
}
