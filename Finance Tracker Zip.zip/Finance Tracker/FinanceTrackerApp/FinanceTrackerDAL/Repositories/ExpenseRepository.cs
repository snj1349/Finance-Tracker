using FinanceTrackerDAL.Models;
using Microsoft.EntityFrameworkCore;

namespace FinanceTrackerDAL.Repositories
{
    public class ExpenseRepository
    {
        private readonly FinanceTrackerDbContext _context;

        public ExpenseRepository()
        {
            _context = new FinanceTrackerDbContext();
        }

        public ExpenseRepository(FinanceTrackerDbContext context)
        {
            _context = context;
        }

        // 1. Get all expenses for a specific user
        public List<Expense> GetExpensesByUser(int userId)
        {
            List<Expense> expenses = new List<Expense>();
            try
            {
                expenses = (from e in _context.Expenses
                            .Include(e => e.Category)
                            where e.UserId == userId
                            orderby e.ExpenseDate descending
                            select e).ToList();
            }
            catch (Exception ex)
            {
                expenses = null;
            }
            return expenses;
        }

        // 2. Get expenses by date range
        public List<Expense> GetExpensesByDateRange(int userId, DateTime start, DateTime end)
        {
            List<Expense> expenses = new List<Expense>();
            try
            {
                expenses = (from e in _context.Expenses
                            .Include(e => e.Category)
                            where e.UserId == userId && 
                                  e.ExpenseDate >= DateOnly.FromDateTime(start) && 
                                  e.ExpenseDate <= DateOnly.FromDateTime(end)
                            orderby e.ExpenseDate descending
                            select e).ToList();
            }
            catch (Exception ex)
            {
                expenses = null;
            }
            return expenses;
        }

        // 3. Get expenses by category
        public List<Expense> GetExpensesByCategory(int userId, int categoryId)
        {
            List<Expense> expenses = new List<Expense>();
            try
            {
                expenses = (from e in _context.Expenses
                            .Include(e => e.Category)
                            where e.UserId == userId && e.CategoryId == categoryId
                            orderby e.ExpenseDate descending
                            select e).ToList();
            }
            catch (Exception ex)
            {
                expenses = null;
            }
            return expenses;
        }

        // 4. Get expense by ID
        public Expense? GetExpenseById(int id)
        {
            Expense? expense = null;
            try
            {
                expense = _context.Expenses
                    .Include(e => e.Category)
                    .FirstOrDefault(e => e.ExpenseId == id);
            }
            catch (Exception ex)
            {
                expense = null;
            }
            return expense;
        }

        // 5. Add new expense
        public bool AddExpense(Expense expense)
        {
            bool result = false;
            try
            {
                expense.CreatedAt = DateTime.Now;
                _context.Expenses.Add(expense);
                _context.SaveChanges();
                result = true;
            }
            catch (Exception ex)
            {
                result = false;
            }
            return result;
        }

        // 6. Update expense
        public int UpdateExpense(Expense expense)
        {
            int result = 0;
            try
            {
                var existingExpense = _context.Expenses.Find(expense.ExpenseId);
                if (existingExpense != null)
                {
                    existingExpense.Amount = expense.Amount;
                    existingExpense.Description = expense.Description;
                    existingExpense.ExpenseDate = expense.ExpenseDate;
                    existingExpense.CategoryId = expense.CategoryId;
                    
                    _context.SaveChanges();
                    result = 1;
                }
                else
                {
                    result = -1;
                }
            }
            catch (Exception ex)
            {
                result = -99;
            }
            return result;
        }

        // 7. Delete expense
        public bool DeleteExpense(int id)
        {
            bool result = false;
            try
            {
                var expense = _context.Expenses.Find(id);
                if (expense != null)
                {
                    _context.Expenses.Remove(expense);
                    _context.SaveChanges();
                    result = true;
                }
                else
                {
                    result = false;
                }
            }
            catch (Exception ex)
            {
                result = false;
            }
            return result;
        }

        // 8. Get total expense for a specific month and year
        public decimal GetTotalExpenseByMonth(int userId, int month, int year)
        {
            decimal total = 0;
            try
            {
                total = (from e in _context.Expenses
                         where e.UserId == userId && 
                               e.ExpenseDate.Month == month && 
                               e.ExpenseDate.Year == year
                         select e.Amount).Sum();
            }
            catch (Exception ex)
            {
                total = 0;
            }
            return total;
        }

        // 9. Get expense summary grouped by category for a specific month and year
        public Dictionary<string, decimal> GetExpenseSummaryByCategory(int userId, int month, int year)
        {
            Dictionary<string, decimal> summary = new Dictionary<string, decimal>();
            try
            {
                var result = (from e in _context.Expenses
                              .Include(e => e.Category)
                              where e.UserId == userId && 
                                    e.ExpenseDate.Month == month && 
                                    e.ExpenseDate.Year == year
                              group e by e.Category.Name into g
                              select new { CategoryName = g.Key, TotalAmount = g.Sum(e => e.Amount) }).ToList();

                summary = result.ToDictionary(x => x.CategoryName, x => x.TotalAmount);
            }
            catch (Exception ex)
            {
                summary = new Dictionary<string, decimal>();
            }
            return summary;
        }
    }
}
