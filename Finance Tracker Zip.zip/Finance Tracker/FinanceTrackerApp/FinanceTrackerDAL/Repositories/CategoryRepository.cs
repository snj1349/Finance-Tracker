using FinanceTrackerDAL.Models;
using Microsoft.EntityFrameworkCore;

namespace FinanceTrackerDAL.Repositories
{
    public class CategoryRepository
    {
        private readonly FinanceTrackerDbContext _context;

        public CategoryRepository()
        {
            _context = new FinanceTrackerDbContext();
        }

        public CategoryRepository(FinanceTrackerDbContext context)
        {
            _context = context;
        }

        // 1. Get all categories for a specific user
        public List<Category> GetCategoriesByUser(int userId)
        {
            List<Category> categories = new List<Category>();
            try
            {
                categories = (from c in _context.Categories
                              where c.UserId == userId
                              orderby c.Name
                              select c).ToList();
            }
            catch (Exception ex)
            {
                categories = null;
            }
            return categories;
        }

        // 2. Get category by ID
        public Category? GetCategoryById(int id)
        {
            Category? category = null;
            try
            {
                category = _context.Categories.Find(id);
            }
            catch (Exception ex)
            {
                category = null;
            }
            return category;
        }

        // 3. Add new category
        public bool AddCategory(Category category)
        {
            bool result = false;
            try
            {
                category.CreatedAt = DateTime.Now;
                _context.Categories.Add(category);
                _context.SaveChanges();
                result = true;
            }
            catch (Exception ex)
            {
                result = false;
            }
            return result;
        }

        // 4. Update category
        public int UpdateCategory(Category category)
        {
            int result = 0;
            try
            {
                var existingCategory = _context.Categories.Find(category.CategoryId);
                if (existingCategory != null)
                {
                    existingCategory.Name = category.Name;
                    _context.SaveChanges();
                    result = 1;
                }
                else
                {
                    result = -1;
                }
            }
            catch (Exception ex)
            {
                result = -99;
            }
            return result;
        }

        // 5. Delete category
        public bool DeleteCategory(int id)
        {
            bool result = false;
            try
            {
                var category = _context.Categories.Find(id);
                if (category != null)
                {
                    // Check if category has any expenses or budgets
                    bool hasExpenses = _context.Expenses.Any(e => e.CategoryId == id);
                    bool hasBudgets = _context.Budgets.Any(b => b.CategoryId == id);
                    
                    if (!hasExpenses && !hasBudgets)
                    {
                        // Category has no related data, safe to delete
                        _context.Categories.Remove(category);
                        _context.SaveChanges();
                        result = true;
                    }
                    else
                    {
                        // Category has related data, cannot delete
                        result = false;
                    }
                }
                else
                {
                    result = false;
                }
            }
            catch (Exception ex)
            {
                result = false;
            }
            return result;
        }
    }
}
