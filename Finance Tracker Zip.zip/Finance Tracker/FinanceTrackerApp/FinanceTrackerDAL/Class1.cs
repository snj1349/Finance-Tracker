﻿namespace FinanceTrackerDAL
{
    public class Class1
    {

    }
}
