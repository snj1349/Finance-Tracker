﻿using FinanceTrackerDAL.Models;
using FinanceTrackerDAL.Repositories;
using System;

namespace FinanceTrackerConsoleApp
{
    internal class Program
    {
        public static UserRepository UserRepo { get; set; }
        public static CategoryRepository CategoryRepo { get; set; }
        public static ExpenseRepository ExpenseRepo { get; set; }
        public static BudgetRepository BudgetRepo { get; set; }

        static Program()
        {
            UserRepo = new UserRepository();
            CategoryRepo = new CategoryRepository();
            ExpenseRepo = new ExpenseRepository();
            BudgetRepo = new BudgetRepository();
        }

        static void Main(string[] args)
        {
            Console.WriteLine("=== Finance Tracker Console Application ===\n");

            // Test User Repository Functions
            TestGetAllUsers();
            TestGetUserById();
            TestGetUserByEmail();
            TestAddUser();
            TestUpdateUser();
            TestDeleteUser();

            // Test Category Repository Functions
            TestGetCategoriesByUser();
            TestGetCategoryById();
            TestAddCategory();
            TestUpdateCategory();
            TestDeleteCategory();

            // Test Expense Repository Functions
            TestGetExpensesByUser();
            TestGetExpensesByDateRange();
            TestGetExpensesByCategory();
            TestGetExpenseById();
            TestAddExpense();
            TestUpdateExpense();
            TestDeleteExpense();
            TestGetTotalExpenseByMonth();
            TestGetExpenseSummaryByCategory();

            // Test Budget Repository Functions
            TestGetBudgetsByUser();
            TestGetBudgetById();
            TestAddBudget();
            TestUpdateBudget();
            TestDeleteBudget();
            TestGetBudgetForCategory();
            TestIsBudgetExceeded();
            TestGetBudgetVsActual();

            Console.WriteLine("\nPress any key to exit...");
            Console.ReadKey();
        }

        // ==================== USER REPOSITORY TESTS ====================
        public static void TestGetAllUsers()
        {
            Console.WriteLine("--- Testing GetAllUsers ---");
            List<User> users = UserRepo.GetAllUsers();
            if (users != null && users.Count > 0)
            {
                Console.WriteLine("User List:");
                foreach (var user in users)
                {
                    Console.WriteLine($"ID: {user.UserId}, Name: {user.Name}, Email: {user.Email}, Role: {user.Role}");
                }
            }
            else
            {
                Console.WriteLine("No users found or an error occurred.");
            }
            Console.WriteLine();
        }

        public static void TestGetUserById()
        {
            Console.WriteLine("--- Testing GetUserById ---");
            User user = UserRepo.GetUserById(1);
            if (user != null)
            {
                Console.WriteLine($"Found user: ID: {user.UserId}, Name: {user.Name}, Email: {user.Email}");
            }
            else
            {
                Console.WriteLine("User not found or an error occurred.");
            }
            Console.WriteLine();
        }

        public static void TestGetUserByEmail()
        {
            Console.WriteLine("--- Testing GetUserByEmail ---");
            User user = UserRepo.GetUserByEmail("saurabh@example.com");
            if (user != null)
            {
                Console.WriteLine($"Found user by email: ID: {user.UserId}, Name: {user.Name}, Email: {user.Email}");
            }
            else
            {
                Console.WriteLine("User not found or an error occurred.");
            }
            Console.WriteLine();
        }

        public static void TestAddUser()
        {
            Console.WriteLine("--- Testing AddUser ---");
            User newUser = new User
            {
                Name = "John Doe",
                Email = "john.doe@example.com",
                PasswordHash = "hashedpassword123",
                Role = "User"
            };

            bool isAdded = UserRepo.AddUser(newUser);
            if (isAdded)
            {
                Console.WriteLine("User added successfully.");
            }
            else
            {
                Console.WriteLine("Failed to add the user.");
            }
            Console.WriteLine();
        }

        public static void TestUpdateUser()
        {
            Console.WriteLine("--- Testing UpdateUser ---");
            User updatedUser = new User
            {
                UserId = 1,
                Name = "Saurabh Jha Updated",
                Email = "saurabh.updated@example.com",
                PasswordHash = "newhashedpassword123",
                Role = "User"
            };

            int updateResult = UserRepo.UpdateUser(updatedUser);
            if (updateResult == 1)
            {
                Console.WriteLine("User updated successfully.");
            }
            else if (updateResult == -1)
            {
                Console.WriteLine("User not found.");
            }
            else
            {
                Console.WriteLine("An error occurred while updating user.");
            }
            Console.WriteLine();
        }

        public static void TestDeleteUser()
        {
            Console.WriteLine("--- Testing DeleteUser ---");
            int userId = 3; // Assume a valid user ID with no related data
            bool deleteResult = UserRepo.DeleteUser(userId);
            if (deleteResult)
            {
                Console.WriteLine("User deleted successfully.");
            }
            else
            {
                Console.WriteLine("User could not be deleted (either does not exist or has associated data).");
            }
            Console.WriteLine();
        }

        // ==================== CATEGORY REPOSITORY TESTS ====================
        public static void TestGetCategoriesByUser()
        {
            Console.WriteLine("--- Testing GetCategoriesByUser ---");
            List<Category> categories = CategoryRepo.GetCategoriesByUser(1);
            if (categories != null && categories.Count > 0)
            {
                Console.WriteLine("Categories for User 1:");
                foreach (var category in categories)
                {
                    Console.WriteLine($"ID: {category.CategoryId}, Name: {category.Name}");
                }
            }
            else
            {
                Console.WriteLine("No categories found or an error occurred.");
            }
            Console.WriteLine();
        }

        public static void TestGetCategoryById()
        {
            Console.WriteLine("--- Testing GetCategoryById ---");
            Category category = CategoryRepo.GetCategoryById(1);
            if (category != null)
            {
                Console.WriteLine($"Found category: ID: {category.CategoryId}, Name: {category.Name}");
            }
            else
            {
                Console.WriteLine("Category not found or an error occurred.");
            }
            Console.WriteLine();
        }

        public static void TestAddCategory()
        {
            Console.WriteLine("--- Testing AddCategory ---");
            Category newCategory = new Category
            {
                Name = "Entertainment",
                UserId = 1
            };

            bool isAdded = CategoryRepo.AddCategory(newCategory);
            if (isAdded)
            {
                Console.WriteLine("Category added successfully.");
            }
            else
            {
                Console.WriteLine("Failed to add the category.");
            }
            Console.WriteLine();
        }

        public static void TestUpdateCategory()
        {
            Console.WriteLine("--- Testing UpdateCategory ---");
            Category updatedCategory = new Category
            {
                CategoryId = 1,
                Name = "Food & Dining",
                UserId = 1
            };

            int updateResult = CategoryRepo.UpdateCategory(updatedCategory);
            if (updateResult == 1)
            {
                Console.WriteLine("Category updated successfully.");
            }
            else if (updateResult == -1)
            {
                Console.WriteLine("Category not found.");
            }
            else
            {
                Console.WriteLine("An error occurred while updating category.");
            }
            Console.WriteLine();
        }

        public static void TestDeleteCategory()
        {
            Console.WriteLine("--- Testing DeleteCategory ---");
            int categoryId = 5; // Assume a valid category ID with no related data
            bool deleteResult = CategoryRepo.DeleteCategory(categoryId);
            if (deleteResult)
            {
                Console.WriteLine("Category deleted successfully.");
            }
            else
            {
                Console.WriteLine("Category could not be deleted (either does not exist or has associated data).");
            }
            Console.WriteLine();
        }

        // ==================== EXPENSE REPOSITORY TESTS ====================
        public static void TestGetExpensesByUser()
        {
            Console.WriteLine("--- Testing GetExpensesByUser ---");
            List<Expense> expenses = ExpenseRepo.GetExpensesByUser(1);
            if (expenses != null && expenses.Count > 0)
            {
                Console.WriteLine("Expenses for User 1:");
                foreach (var expense in expenses)
                {
                    Console.WriteLine($"ID: {expense.ExpenseId}, Amount: ${expense.Amount}, Description: {expense.Description}, Date: {expense.ExpenseDate}, Category: {expense.Category?.Name}");
                }
            }
            else
            {
                Console.WriteLine("No expenses found or an error occurred.");
            }
            Console.WriteLine();
        }

        public static void TestGetExpensesByDateRange()
        {
            Console.WriteLine("--- Testing GetExpensesByDateRange ---");
            DateTime startDate = new DateTime(2025, 8, 1);
            DateTime endDate = new DateTime(2025, 8, 31);
            List<Expense> expenses = ExpenseRepo.GetExpensesByDateRange(1, startDate, endDate);
            if (expenses != null && expenses.Count > 0)
            {
                Console.WriteLine($"Expenses for User 1 from {startDate.ToShortDateString()} to {endDate.ToShortDateString()}:");
                foreach (var expense in expenses)
                {
                    Console.WriteLine($"ID: {expense.ExpenseId}, Amount: ${expense.Amount}, Description: {expense.Description}, Date: {expense.ExpenseDate}");
                }
            }
            else
            {
                Console.WriteLine("No expenses found in date range or an error occurred.");
            }
            Console.WriteLine();
        }

        public static void TestGetExpensesByCategory()
        {
            Console.WriteLine("--- Testing GetExpensesByCategory ---");
            List<Expense> expenses = ExpenseRepo.GetExpensesByCategory(1, 1);
            if (expenses != null && expenses.Count > 0)
            {
                Console.WriteLine("Expenses for User 1 in Category 1 (Food):");
                foreach (var expense in expenses)
                {
                    Console.WriteLine($"ID: {expense.ExpenseId}, Amount: ${expense.Amount}, Description: {expense.Description}, Date: {expense.ExpenseDate}");
                }
            }
            else
            {
                Console.WriteLine("No expenses found for category or an error occurred.");
            }
            Console.WriteLine();
        }

        public static void TestGetExpenseById()
        {
            Console.WriteLine("--- Testing GetExpenseById ---");
            Expense expense = ExpenseRepo.GetExpenseById(1);
            if (expense != null)
            {
                Console.WriteLine($"Found expense: ID: {expense.ExpenseId}, Amount: ${expense.Amount}, Description: {expense.Description}, Category: {expense.Category?.Name}");
            }
            else
            {
                Console.WriteLine("Expense not found or an error occurred.");
            }
            Console.WriteLine();
        }

        public static void TestAddExpense()
        {
            Console.WriteLine("--- Testing AddExpense ---");
            Expense newExpense = new Expense
            {
                Amount = 75.50m,
                Description = "Movie tickets",
                ExpenseDate = DateOnly.FromDateTime(DateTime.Now),
                CategoryId = 1,
                UserId = 1
            };

            bool isAdded = ExpenseRepo.AddExpense(newExpense);
            if (isAdded)
            {
                Console.WriteLine("Expense added successfully.");
            }
            else
            {
                Console.WriteLine("Failed to add the expense.");
            }
            Console.WriteLine();
        }

        public static void TestUpdateExpense()
        {
            Console.WriteLine("--- Testing UpdateExpense ---");
            Expense updatedExpense = new Expense
            {
                ExpenseId = 1,
                Amount = 550.00m,
                Description = "Grocery shopping updated",
                ExpenseDate = DateOnly.FromDateTime(DateTime.Now),
                CategoryId = 1,
                UserId = 1
            };

            int updateResult = ExpenseRepo.UpdateExpense(updatedExpense);
            if (updateResult == 1)
            {
                Console.WriteLine("Expense updated successfully.");
            }
            else if (updateResult == -1)
            {
                Console.WriteLine("Expense not found.");
            }
            else
            {
                Console.WriteLine("An error occurred while updating expense.");
            }
            Console.WriteLine();
        }

        public static void TestDeleteExpense()
        {
            Console.WriteLine("--- Testing DeleteExpense ---");
            int expenseId = 5; // Assume a valid expense ID
            bool deleteResult = ExpenseRepo.DeleteExpense(expenseId);
            if (deleteResult)
            {
                Console.WriteLine("Expense deleted successfully.");
            }
            else
            {
                Console.WriteLine("Expense could not be deleted (either does not exist).");
            }
            Console.WriteLine();
        }

        public static void TestGetTotalExpenseByMonth()
        {
            Console.WriteLine("--- Testing GetTotalExpenseByMonth ---");
            decimal totalExpense = ExpenseRepo.GetTotalExpenseByMonth(1, 8, 2025);
            Console.WriteLine($"Total expense for User 1 in August 2025: ${totalExpense}");
            Console.WriteLine();
        }

        public static void TestGetExpenseSummaryByCategory()
        {
            Console.WriteLine("--- Testing GetExpenseSummaryByCategory ---");
            Dictionary<string, decimal> summary = ExpenseRepo.GetExpenseSummaryByCategory(1, 8, 2025);
            if (summary.Count > 0)
            {
                Console.WriteLine("Expense summary by category for User 1 in August 2025:");
                foreach (var item in summary)
                {
                    Console.WriteLine($"Category: {item.Key}, Total: ${item.Value}");
                }
            }
            else
            {
                Console.WriteLine("No expense summary found or an error occurred.");
            }
            Console.WriteLine();
        }

        // ==================== BUDGET REPOSITORY TESTS ====================
        public static void TestGetBudgetsByUser()
        {
            Console.WriteLine("--- Testing GetBudgetsByUser ---");
            List<Budget> budgets = BudgetRepo.GetBudgetsByUser(1);
            if (budgets != null && budgets.Count > 0)
            {
                Console.WriteLine("Budgets for User 1:");
                foreach (var budget in budgets)
                {
                    Console.WriteLine($"ID: {budget.BudgetId}, Category: {budget.Category?.Name}, Amount: ${budget.Amount}, Month: {budget.Month}, Year: {budget.Year}");
                }
            }
            else
            {
                Console.WriteLine("No budgets found or an error occurred.");
            }
            Console.WriteLine();
        }

        public static void TestGetBudgetById()
        {
            Console.WriteLine("--- Testing GetBudgetById ---");
            Budget budget = BudgetRepo.GetBudgetById(1);
            if (budget != null)
            {
                Console.WriteLine($"Found budget: ID: {budget.BudgetId}, Category: {budget.Category?.Name}, Amount: ${budget.Amount}");
            }
            else
            {
                Console.WriteLine("Budget not found or an error occurred.");
            }
            Console.WriteLine();
        }

        public static void TestAddBudget()
        {
            Console.WriteLine("--- Testing AddBudget ---");
            Budget newBudget = new Budget
            {
                UserId = 1,
                CategoryId = 1,
                Amount = 6000.00m,
                Month = 9,
                Year = 2025
            };

            bool isAdded = BudgetRepo.AddBudget(newBudget);
            if (isAdded)
            {
                Console.WriteLine("Budget added successfully.");
            }
            else
            {
                Console.WriteLine("Failed to add the budget.");
            }
            Console.WriteLine();
        }

        public static void TestUpdateBudget()
        {
            Console.WriteLine("--- Testing UpdateBudget ---");
            Budget updatedBudget = new Budget
            {
                BudgetId = 1,
                UserId = 1,
                CategoryId = 1,
                Amount = 5500.00m,
                Month = 8,
                Year = 2025
            };

            int updateResult = BudgetRepo.UpdateBudget(updatedBudget);
            if (updateResult == 1)
            {
                Console.WriteLine("Budget updated successfully.");
            }
            else if (updateResult == -1)
            {
                Console.WriteLine("Budget not found.");
            }
            else
            {
                Console.WriteLine("An error occurred while updating budget.");
            }
            Console.WriteLine();
        }

        public static void TestDeleteBudget()
        {
            Console.WriteLine("--- Testing DeleteBudget ---");
            int budgetId = 4; // Assume a valid budget ID
            bool deleteResult = BudgetRepo.DeleteBudget(budgetId);
            if (deleteResult)
            {
                Console.WriteLine("Budget deleted successfully.");
            }
            else
            {
                Console.WriteLine("Budget could not be deleted (either does not exist).");
            }
            Console.WriteLine();
        }

        public static void TestGetBudgetForCategory()
        {
            Console.WriteLine("--- Testing GetBudgetForCategory ---");
            decimal budgetAmount = BudgetRepo.GetBudgetForCategory(1, 1, 8, 2025);
            Console.WriteLine($"Budget for User 1, Category 1 in August 2025: ${budgetAmount}");
            Console.WriteLine();
        }

        public static void TestIsBudgetExceeded()
        {
            Console.WriteLine("--- Testing IsBudgetExceeded ---");
            bool isExceeded = BudgetRepo.IsBudgetExceeded(1, 1, 8, 2025);
            Console.WriteLine($"Budget exceeded for User 1, Category 1 in August 2025: {isExceeded}");
            Console.WriteLine();
        }

        public static void TestGetBudgetVsActual()
        {
            Console.WriteLine("--- Testing GetBudgetVsActual ---");
            var budgetVsActual = BudgetRepo.GetBudgetVsActual(1, 8, 2025);
            if (budgetVsActual.Count > 0)
            {
                Console.WriteLine("Budget vs Actual for User 1 in August 2025:");
                foreach (var item in budgetVsActual)
                {
                    Console.WriteLine($"Category: {item.Key}, Budget: ${item.Value.Budget}, Actual: ${item.Value.Actual}, Remaining: ${item.Value.Remaining}");
                }
            }
            else
            {
                Console.WriteLine("No budget vs actual data found or an error occurred.");
            }
            Console.WriteLine();
        }
    }
}
