namespace FinanceTrackerWebService.Models
{
	public class UserDto
	{
		public int UserId { get; set; }
		public string Name { get; set; }
		public string Email { get; set; }
		public string? Role { get; set; }
	}
}
