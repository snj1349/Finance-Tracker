using FinanceTrackerDAL.Models;
using FinanceTrackerDAL.Repositories;
using FinanceTrackerWebService.Models;
using Microsoft.AspNetCore.Mvc;

namespace FinanceTrackerWebService.Controllers
{
	[ApiController]
	[Route("api/[controller]")]
	public class ExpensesController : ControllerBase
	{
		private readonly ExpenseRepository _repo;

		public ExpensesController()
		{
			_repo = new ExpenseRepository();
		}

		[HttpGet("by-user/{userId:int}")]
		public ActionResult<IEnumerable<ExpenseDto>> GetByUser(int userId)
		{
			var expenses = _repo.GetExpensesByUser(userId);
			if (expenses == null) return StatusCode(500);
			var result = expenses.Select(e => new ExpenseDto
			{
				ExpenseId = e.ExpenseId,
				Amount = e.Amount,
				Description = e.Description,
				ExpenseDate = e.ExpenseDate,
				CategoryId = e.CategoryId,
				UserId = e.UserId,
				CategoryName = e.Category?.Name
			}).ToList();
			return Ok(result);
		}

		[HttpGet("{id:int}")]
		public ActionResult<ExpenseDto> GetById(int id)
		{
			var e = _repo.GetExpenseById(id);
			if (e == null) return NotFound();
			return Ok(new ExpenseDto
			{
				ExpenseId = e.ExpenseId,
				Amount = e.Amount,
				Description = e.Description,
				ExpenseDate = e.ExpenseDate,
				CategoryId = e.CategoryId,
				UserId = e.UserId,
				CategoryName = e.Category?.Name
			});
		}

		[HttpGet("by-date/{userId:int}")]
		public ActionResult<IEnumerable<ExpenseDto>> GetByDateRange(int userId, [FromQuery] DateTime start, [FromQuery] DateTime end)
		{
			var expenses = _repo.GetExpensesByDateRange(userId, start, end);
			if (expenses == null) return StatusCode(500);
			var result = expenses.Select(e => new ExpenseDto
			{
				ExpenseId = e.ExpenseId,
				Amount = e.Amount,
				Description = e.Description,
				ExpenseDate = e.ExpenseDate,
				CategoryId = e.CategoryId,
				UserId = e.UserId,
				CategoryName = e.Category?.Name
			}).ToList();
			return Ok(result);
		}

		[HttpGet("by-category/{userId:int}/{categoryId:int}")]
		public ActionResult<IEnumerable<ExpenseDto>> GetByCategory(int userId, int categoryId)
		{
			var expenses = _repo.GetExpensesByCategory(userId, categoryId);
			if (expenses == null) return StatusCode(500);
			var result = expenses.Select(e => new ExpenseDto
			{
				ExpenseId = e.ExpenseId,
				Amount = e.Amount,
				Description = e.Description,
				ExpenseDate = e.ExpenseDate,
				CategoryId = e.CategoryId,
				UserId = e.UserId,
				CategoryName = e.Category?.Name
			}).ToList();
			return Ok(result);
		}

		[HttpPost]
		public IActionResult Create([FromBody] ExpenseDto dto)
		{
			var entity = new Expense
			{
				Amount = dto.Amount,
				Description = dto.Description,
				ExpenseDate = dto.ExpenseDate,
				CategoryId = dto.CategoryId,
				UserId = dto.UserId
			};
			var ok = _repo.AddExpense(entity);
			if (!ok) return StatusCode(500);
			return CreatedAtAction(nameof(GetById), new { id = entity.ExpenseId }, new ExpenseDto
			{
				ExpenseId = entity.ExpenseId,
				Amount = entity.Amount,
				Description = entity.Description,
				ExpenseDate = entity.ExpenseDate,
				CategoryId = entity.CategoryId,
				UserId = entity.UserId
			});
		}

		[HttpPut("{id:int}")]
		public IActionResult Update(int id, [FromBody] ExpenseDto dto)
		{
			if (id != dto.ExpenseId) return BadRequest("ID mismatch");
			var entity = _repo.GetExpenseById(id);
			if (entity == null) return NotFound();
			entity.Amount = dto.Amount;
			entity.Description = dto.Description;
			entity.ExpenseDate = dto.ExpenseDate;
			entity.CategoryId = dto.CategoryId;
			var result = _repo.UpdateExpense(entity);
			if (result == 1) return NoContent();
			if (result == -1) return NotFound();
			return StatusCode(500);
		}

		[HttpDelete("{id:int}")]
		public IActionResult Delete(int id)
		{
			var ok = _repo.DeleteExpense(id);
			if (!ok) return NotFound();
			return NoContent();
		}

		[HttpGet("total/{userId:int}/{month:int}/{year:int}")]
		public ActionResult<decimal> GetTotalByMonth(int userId, int month, int year)
		{
			var total = _repo.GetTotalExpenseByMonth(userId, month, year);
			return Ok(total);
		}

		[HttpGet("summary-by-category/{userId:int}/{month:int}/{year:int}")]
		public ActionResult<IEnumerable<object>> GetSummaryByCategory(int userId, int month, int year)
		{
			var summary = _repo.GetExpenseSummaryByCategory(userId, month, year)
				.Select(kvp => new { Category = kvp.Key, Total = kvp.Value })
				.ToList();
			return Ok(summary);
		}
	}
}
