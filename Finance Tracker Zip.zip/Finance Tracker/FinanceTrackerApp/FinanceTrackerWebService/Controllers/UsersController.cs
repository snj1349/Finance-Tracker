using FinanceTrackerDAL.Models;
using FinanceTrackerDAL.Repositories;
using FinanceTrackerWebService.Models;
using Microsoft.AspNetCore.Mvc;

namespace FinanceTrackerWebService.Controllers
{
	[ApiController]
	[Route("api/[controller]")]
	public class UsersController : ControllerBase
	{
		private readonly UserRepository _repo;

		public UsersController()
		{
			_repo = new UserRepository();
		}

		[HttpGet]
		public ActionResult<IEnumerable<UserDto>> GetAll()
		{
			var users = _repo.GetAllUsers();
			if (users == null) return StatusCode(500);
			var result = users.Select(u => new UserDto
			{
				UserId = u.UserId,
				Name = u.Name,
				Email = u.Email,
				Role = u.Role
			}).ToList();
			return Ok(result);
		}

		[HttpGet("{id:int}")]
		public ActionResult<UserDto> GetById(int id)
		{
			var u = _repo.GetUserById(id);
			if (u == null) return NotFound();
			return Ok(new UserDto { UserId = u.UserId, Name = u.Name, Email = u.Email, Role = u.Role });
		}

		[HttpGet("by-email/{email}")]
		public ActionResult<UserDto> GetByEmail(string email)
		{
			var u = _repo.GetUserByEmail(email);
			if (u == null) return NotFound();
			return Ok(new UserDto { UserId = u.UserId, Name = u.Name, Email = u.Email, Role = u.Role });
		}

		[HttpPost]
		public IActionResult Create([FromBody] UserDto dto)
		{
			var entity = new User { Name = dto.Name, Email = dto.Email, PasswordHash = "", Role = dto.Role };
			var ok = _repo.AddUser(entity);
			if (!ok) return StatusCode(500);
			return CreatedAtAction(nameof(GetById), new { id = entity.UserId }, new UserDto { UserId = entity.UserId, Name = entity.Name, Email = entity.Email, Role = entity.Role });
		}

		[HttpPut("{id:int}")]
		public IActionResult Update(int id, [FromBody] UserDto dto)
		{
			var entity = _repo.GetUserById(id);
			if (entity == null) return NotFound();
			entity.Name = dto.Name;
			entity.Email = dto.Email;
			entity.Role = dto.Role;
			var result = _repo.UpdateUser(entity);
			if (result == 1) return NoContent();
			if (result == -1) return NotFound();
			return StatusCode(500);
		}

		[HttpDelete("{id:int}")]
		public IActionResult Delete(int id)
		{
			var ok = _repo.DeleteUser(id);
			if (!ok) return Conflict("Cannot delete user or user not found.");
			return NoContent();
		}
	}
}
