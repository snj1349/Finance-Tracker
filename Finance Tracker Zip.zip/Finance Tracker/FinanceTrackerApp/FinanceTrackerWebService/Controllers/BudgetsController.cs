using FinanceTrackerDAL.Models;
using FinanceTrackerDAL.Repositories;
using FinanceTrackerWebService.Models;
using Microsoft.AspNetCore.Mvc;

namespace FinanceTrackerWebService.Controllers
{
	[ApiController]
	[Route("api/[controller]")]
	public class BudgetsController : ControllerBase
	{
		private readonly BudgetRepository _repo;

		public BudgetsController()
		{
			_repo = new BudgetRepository();
		}

		[HttpGet("by-user/{userId:int}")]
		public ActionResult<IEnumerable<BudgetDto>> GetByUser(int userId)
		{
			var budgets = _repo.GetBudgetsByUser(userId);
			if (budgets == null) return StatusCode(500);
			var result = budgets.Select(b => new BudgetDto
			{
				BudgetId = b.BudgetId,
				UserId = b.UserId,
				CategoryId = b.CategoryId,
				Amount = b.Amount,
				Month = b.Month,
				Year = b.Year,
				CategoryName = b.Category?.Name
			}).ToList();
			return Ok(result);
		}

		[HttpGet("{id:int}")]
		public ActionResult<BudgetDto> GetById(int id)
		{
			var b = _repo.GetBudgetById(id);
			if (b == null) return NotFound();
			return Ok(new BudgetDto
			{
				BudgetId = b.BudgetId,
				UserId = b.UserId,
				CategoryId = b.CategoryId,
				Amount = b.Amount,
				Month = b.Month,
				Year = b.Year,
				CategoryName = b.Category?.Name
			});
		}

		[HttpPost]
		public IActionResult Create([FromBody] BudgetDto dto)
		{
			var entity = new Budget
			{
				UserId = dto.UserId,
				CategoryId = dto.CategoryId,
				Amount = dto.Amount,
				Month = dto.Month,
				Year = dto.Year
			};
			var ok = _repo.AddBudget(entity);
			if (!ok) return StatusCode(500);
			return CreatedAtAction(nameof(GetById), new { id = entity.BudgetId }, new BudgetDto
			{
				BudgetId = entity.BudgetId,
				UserId = entity.UserId,
				CategoryId = entity.CategoryId,
				Amount = entity.Amount,
				Month = entity.Month,
				Year = entity.Year
			});
		}

		[HttpPut("{id:int}")]
		public IActionResult Update(int id, [FromBody] BudgetDto dto)
		{
			if (id != dto.BudgetId) return BadRequest("ID mismatch");
			var entity = _repo.GetBudgetById(id);
			if (entity == null) return NotFound();
			entity.Amount = dto.Amount;
			entity.Month = dto.Month;
			entity.Year = dto.Year;
			var result = _repo.UpdateBudget(entity);
			if (result == 1) return NoContent();
			if (result == -1) return NotFound();
			return StatusCode(500);
		}

		[HttpDelete("{id:int}")]
		public IActionResult Delete(int id)
		{
			var ok = _repo.DeleteBudget(id);
			if (!ok) return NotFound();
			return NoContent();
		}

		[HttpGet("amount/{userId:int}/{categoryId:int}/{month:int}/{year:int}")]
		public ActionResult<decimal> GetBudgetAmount(int userId, int categoryId, int month, int year)
		{
			var amount = _repo.GetBudgetForCategory(userId, categoryId, month, year);
			return Ok(amount);
		}

		[HttpGet("is-exceeded/{userId:int}/{categoryId:int}/{month:int}/{year:int}")]
		public ActionResult<bool> IsExceeded(int userId, int categoryId, int month, int year)
		{
			var isExceeded = _repo.IsBudgetExceeded(userId, categoryId, month, year);
			return Ok(isExceeded);
		}

		[HttpGet("vs-actual/{userId:int}/{month:int}/{year:int}")]
		public ActionResult<IEnumerable<object>> GetBudgetVsActual(int userId, int month, int year)
		{
			var data = _repo.GetBudgetVsActual(userId, month, year)
				.Select(kvp => new { Category = kvp.Key, Budget = kvp.Value.Budget, Actual = kvp.Value.Actual, Remaining = kvp.Value.Remaining })
				.ToList();
			return Ok(data);
		}
	}
}
