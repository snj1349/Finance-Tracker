using FinanceTrackerDAL.Models;
using FinanceTrackerDAL.Repositories;
using FinanceTrackerWebService.Models;
using Microsoft.AspNetCore.Mvc;

namespace FinanceTrackerWebService.Controllers
{
	[ApiController]
	[Route("api/[controller]")]
	public class CategoriesController : ControllerBase
	{
		private readonly CategoryRepository _repo;

		public CategoriesController()
		{
			_repo = new CategoryRepository();
		}

		[HttpGet("by-user/{userId:int}")]
		public ActionResult<IEnumerable<CategoryDto>> GetByUser(int userId)
		{
			var categories = _repo.GetCategoriesByUser(userId);
			if (categories == null) return StatusCode(500);
			var result = categories.Select(c => new CategoryDto { CategoryId = c.CategoryId, Name = c.Name, UserId = c.UserId }).ToList();
			return Ok(result);
		}

		[HttpGet("{id:int}")]
		public ActionResult<CategoryDto> GetById(int id)
		{
			var c = _repo.GetCategoryById(id);
			if (c == null) return NotFound();
			return Ok(new CategoryDto { CategoryId = c.CategoryId, Name = c.Name, UserId = c.UserId });
		}

		[HttpPost]
		public IActionResult Create([FromBody] CategoryDto dto)
		{
			var entity = new Category { Name = dto.Name, UserId = dto.UserId };
			var ok = _repo.AddCategory(entity);
			if (!ok) return StatusCode(500);
			return CreatedAtAction(nameof(GetById), new { id = entity.CategoryId }, new CategoryDto { CategoryId = entity.CategoryId, Name = entity.Name, UserId = entity.UserId });
		}

		[HttpPut("{id:int}")]
		public IActionResult Update(int id, [FromBody] CategoryDto dto)
		{
			if (id != dto.CategoryId) return BadRequest("ID mismatch");
			var entity = _repo.GetCategoryById(id);
			if (entity == null) return NotFound();
			entity.Name = dto.Name;
			var result = _repo.UpdateCategory(entity);
			if (result == 1) return NoContent();
			if (result == -1) return NotFound();
			return StatusCode(500);
		}

		[HttpDelete("{id:int}")]
		public IActionResult Delete(int id)
		{
			var ok = _repo.DeleteCategory(id);
			if (!ok) return Conflict("Cannot delete category or category not found.");
			return NoContent();
		}
	}
}
