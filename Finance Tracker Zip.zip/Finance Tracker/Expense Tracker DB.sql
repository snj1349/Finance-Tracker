USE [master]
GO

IF (EXISTS (SELECT name FROM master.dbo.sysdatabases WHERE ('[' + name + ']' = N'FinanceTrackerDB'OR name = N'FinanceTrackerDB')))
DROP DATABASE FinanceTrackerDB

CREATE DATABASE FinanceTrackerDB
GO

USE FinanceTrackerDB
GO


-- =========================
-- Users Table
-- =========================
CREATE TABLE Users (
    UserId INT PRIMARY KEY IDENTITY(1,1),
    Name NVARCHAR(100) NOT NULL,
    Email NVARCHAR(150) UNIQUE NOT NULL,
    PasswordHash NVARCHAR(255) NOT NULL,   -- store hashed password
    Role NVARCHAR(20) DEFAULT 'User',      -- 'User' or 'Admin'
    CreatedAt DATETIME DEFAULT GETDATE()
);
GO

-- =========================
-- Categories Table
-- =========================
CREATE TABLE Categories (
    CategoryId INT PRIMARY KEY IDENTITY(1,1),
    Name NVARCHAR(100) NOT NULL,
    UserId INT NOT NULL,
    CreatedAt DATETIME DEFAULT GETDATE(),
    FOREIGN KEY (UserId) REFERENCES Users(UserId) ON DELETE CASCADE
);
GO

-- =========================
-- Expenses Table
-- =========================
CREATE TABLE Expenses (
    ExpenseId INT PRIMARY KEY IDENTITY(1,1),
    Amount DECIMAL(10,2) NOT NULL,
    Description NVARCHAR(255),
    ExpenseDate DATE NOT NULL,
    CategoryId INT NOT NULL,
    UserId INT NOT NULL,
    CreatedAt DATETIME DEFAULT GETDATE(),
    FOREIGN KEY (CategoryId) REFERENCES Categories(CategoryId) ON DELETE CASCADE,
    FOREIGN KEY (UserId) REFERENCES Users(UserId) -- No cascade here to avoid multiple paths
);
GO

-- =========================
-- Budgets Table (Optional)
-- =========================
CREATE TABLE Budgets (
    BudgetId INT PRIMARY KEY IDENTITY(1,1),
    UserId INT NOT NULL,
    CategoryId INT NOT NULL,
    Amount DECIMAL(10,2) NOT NULL,
    Month INT NOT NULL,   -- 1-12
    Year INT NOT NULL,
    CreatedAt DATETIME DEFAULT GETDATE(),
    FOREIGN KEY (UserId) REFERENCES Users(UserId),
    FOREIGN KEY (CategoryId) REFERENCES Categories(CategoryId)
);
GO

-- =========================
-- Insert Some Sample Data
-- =========================

-- Users
INSERT INTO Users (Name, Email, PasswordHash, Role)
VALUES 
('Saurabh Jha', 'saurabh@example.com', 'hashedpassword123', 'User'),
('Admin User', 'admin@example.com', 'hashedadminpass', 'Admin');
GO

-- Categories
INSERT INTO Categories (Name, UserId) 
VALUES 
('Food', 1),
('Travel', 1),
('Rent', 1),
('Shopping', 1);
GO

-- Expenses
INSERT INTO Expenses (Amount, Description, ExpenseDate, CategoryId, UserId)
VALUES
(500.00, 'Grocery shopping', '2025-08-01', 1, 1),
(200.00, 'Bus ticket', '2025-08-02', 2, 1),
(15000.00, 'Monthly rent', '2025-08-03', 3, 1),
(1200.00, 'New shoes', '2025-08-05', 4, 1);
GO

-- Budgets (optional)
INSERT INTO Budgets (UserId, CategoryId, Amount, Month, Year)
VALUES
(1, 1, 5000.00, 8, 2025),
(1, 2, 2000.00, 8, 2025),
(1, 3, 15000.00, 8, 2025);
GO

=============================
=============================

-- View all Users
SELECT * FROM Users;
GO

-- View all Categories
SELECT * FROM Categories;
GO

-- View all Expenses
SELECT * FROM Expenses;
GO

-- View all Budgets
SELECT * FROM Budgets;
GO
